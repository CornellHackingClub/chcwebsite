import socket
import sys

def scan_range(addr, start, stop):
    results = []
    # Iterate through ports
    for conn_port in xrange(start,stop):
        try:
            # Make a normal socket just like before
            connSkt = socket.socket(socket.AF_INET, 
                                    socket.SOCK_STREAM)
            # Reuse ports
            connSkt.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            # Don't wait too long...
            connSkt.settimeout(1)
            # Tell it where to send data
            connSkt.connect((addr, conn_port))

            # It's at least open
            print("[*] Open {0}".format(conn_port))
            # Send some data
            connSkt.send("Hello?\r\n")
            # Receive up to 1024 bytes of data
            data = connSkt.recv(1024)
            if data!="": print("\t"+data)
            results.append((conn_port, data))
            connSkt.close()
        except Exception as e:
            pass
    return results

# Get arguments from command line
args = sys.argv
# If first one is filename, remove
if (sys.argv[0]==__file__):
    args = sys.argv[1:]

if len(args)==3:
    addr = args[0]
    start_port = int(args[1])
    end_port = int(args[2])
    print("Scanning {0} from {1} to {2}".format(
        addr,start_port,end_port))
    results = scan_range(addr,start_port,end_port)
    # Do something with results?
else:
    print("Usage: python port_scan.py addr "+
          "start end")