import socket

# Server is on this machine
conn_addr = "localhost"
# We know what port we're listening to
conn_port = 22

try:
    # Make a normal socket just like before
    connSkt = socket.socket(socket.AF_INET, 
                            socket.SOCK_STREAM)
    # Tell it where to send data
    connSkt.connect((conn_addr, conn_port))
    print("Connected to {0}:{1}".format(
            conn_addr,str(conn_port))
          )
    # Send some data
    connSkt.send("Hello?\r\n")
    # Receive up to 1024 bytes of data
    data = connSkt.recv(1024)
    print("Received: "+data)

    connSkt.close()
except Exception as e:
    print("Failed to connect: "+e.message)
