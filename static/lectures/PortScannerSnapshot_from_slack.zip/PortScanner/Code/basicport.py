import socket

# Tells the OS: "My address"
listen_addr = "0.0.0.0"
# Any number you want, though some need
# root priviledge or are already in use
listen_port = 1708

try:
    # Make a socket using some default parameters
    s = socket.socket(socket.AF_INET, 
                      socket.SOCK_STREAM)
    # Reuse ports
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    # Listen for an address at a port
    s.bind((listen_addr,listen_port))
    # Tell the OS to hold up to 5 connections
    s.listen(5)
except Exception as e:
    print("Failed to create socket: "+e.message)

s.close()